const express  = require('express');

const app = express();
const port = 3000;

var clicks  = 0;

app.use(express.static(__dirname + '/public/'));

app.get('/', (request, response) => { 
	response.sendFile('./public/index.html',{root: __dirname}); 
});

app.get('/clicks', (request, response) => { 
	return response.json({clicks: clicks}); 
});

app.post('/smash', (request, response) => {
	clicks++;
	response.json({clicks: clicks});
});

app.listen(port, () => { console.log('Server running')});
