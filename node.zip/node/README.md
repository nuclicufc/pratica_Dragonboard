# Dragonboard
Centralizar o processamento de dispositivos IoT atraves de um servidor que aceita requisições com os dados necessarios.

# Run
Pra executar o projeto primeiro instale as dependencias:

    npm instal

Então depois é so rodar:

    npm run dev

Pronto, o servidor estara iniciado!